angular.module('persistentOLXApp')
    .controller('loginController', function ($scope, $state, persistentOLXFactory, $rootScope) {
        $rootScope.pageName = 'Login';
        $rootScope.searchBox = false;
        $scope.onLoginBtnClick = function () {
            $rootScope.searchBox = true;
        }
    });