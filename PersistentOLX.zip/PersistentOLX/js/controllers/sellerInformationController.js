angular.module('persistentOLXApp')
    .controller('sellerInformationController', function ($scope, persistentOLXFactory, $state) {
        $scope.onSellerInformation = function () {
            $state.go('sellerInformation');
        };
        $scope.onProductDetails = function () {
            $state.go('productDetails');
        };
        var data = persistentOLXFactory.itemDetails;
        $scope.sellerInfo = data.sellerInfo;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });