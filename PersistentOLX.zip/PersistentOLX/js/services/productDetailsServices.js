angular.module('persistentOLXApp')
    .service('productDetailsServices', function () {
        this.phoneID = 'motorola-xoom-with-wi-fi';
    });